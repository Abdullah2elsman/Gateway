import propTypes from "prop-types";
import { useState } from "react";
import styles from "./HeaderMobile.module.css";

import Avatar from "@assets/image/Avatar.png";
import CustomizedMenus from "@components/Gateway-System/CustomizedMenus/CustomizedMenus";
import Inbox from "@components/Gateway-System/Inbox/Inbox";
import Notification from "@components/Gateway-System/Notification/Notification";
import { Button, Divider, IconButton, MenuItem } from "@mui/material";
import Search from "@src/components/Gateway-System/Search/Search";
import checkPermission from "@src/util/CheckPermission";
import { CgProfile } from "react-icons/cg";
import { CiSearch } from "react-icons/ci";
import { FaMessage } from "react-icons/fa6";
import { HiOutlineMenuAlt1 } from "react-icons/hi";
import { IoNotifications } from "react-icons/io5";
import { MdOutlineLogout } from "react-icons/md";

const HeaderMobile = ({
  handleClick,
  handleClose,
  handleOpenMenu,
  profile,
  imgProfile,
  Count_inbox,
  Count_notification,
  handleClearCountInbox,
  handleClearCountNotification,
}) => {
  const [show_search, setShowSearch] = useState(false);
  const [notification, setNotification] = useState(null);
  const [inbox, setInbox] = useState(null);

  return (
    <div className={styles.headerMobile}>
      <div className={styles.headerMobile_content}>
        <div className={styles.menu}>
          <IconButton onClick={handleOpenMenu}>
            <HiOutlineMenuAlt1 className={styles.icon} />
          </IconButton>
        </div>
        <div className={styles.profile}>
          {/* Search */}
          <IconButton onClick={() => setShowSearch(!show_search)}>
            <CiSearch className={styles.icon} size={25} />
          </IconButton>

          <div
            className={[`${styles.search} ${show_search ? styles.show : ""}`]}
          >
            <CiSearch className={styles.icon} />
            <Search />
          </div>
          {/* End Search */}

          <div className={styles.profile_info}>
            {/* Notification*/}
            <div style={{ position: "relative" }}>
              <IconButton
                onClick={handleClearCountNotification}
                onClickCapture={(e) => setNotification(e.currentTarget)}
                aria-controls="notifications"
              >
                <IoNotifications className={styles.icon} size={20} />
              </IconButton>

              <CustomizedMenus
                isOpen={notification}
                handlerClose={() => setNotification(false)}
                width={"90% !important"}
              >
                <Notification closeMenu={() => setNotification(false)} />
              </CustomizedMenus>
              {Count_notification > 0 && (
                <div className={styles.counter}>
                  <span className={styles.counterText}>
                    {Count_notification}
                  </span>
                </div>
              )}
            </div>

            {/* inbox */}
            {checkPermission({
              name: "announcements",
              children: ["view_announcement_replies"],
            }) && (
              <div style={{ position: "relative" }}>
                <IconButton
                  onClick={handleClearCountInbox}
                  onClickCapture={(e) => setInbox(e.currentTarget)}
                  aria-controls="inbox"
                >
                  <FaMessage className={styles.icon} />
                </IconButton>

                <CustomizedMenus
                  isOpen={inbox}
                  handlerClose={() => setInbox(false)}
                  width={"90% !important"}
                >
                  <Inbox closeMenu={() => setInbox(false)} />
                </CustomizedMenus>

                {Count_inbox > 0 && (
                  <div
                    className={styles.counter}
                    style={{ top: "-5px", right: "2px" }}
                  >
                    <span className={styles.counterText}>{Count_inbox}</span>
                  </div>
                )}
              </div>
            )}

            {/* Menu Profile */}
            <Button
              id="basic-button"
              aria-controls={Boolean(profile) ? "basic-menu" : undefined}
              aria-haspopup="true"
              aria-expanded={Boolean(profile) ? "true" : undefined}
              onClick={handleClick}
            >
              {imgProfile ? (
                <img
                  src={(() => {
                    // تنظيف اسم الملف
                    let cleanFilename = imgProfile;
                    if (cleanFilename.includes('|')) cleanFilename = cleanFilename.split('|')[0];
                    if (cleanFilename.includes('/')) cleanFilename = cleanFilename.split('/').pop();
                    if (cleanFilename.includes('?')) cleanFilename = cleanFilename.split('?')[0];
                    
                    const baseUrl = import.meta.env.VITE_API_URL_image.replace(/\/$/, '');
                    return `${baseUrl}/storage/user/${cleanFilename}`;
                  })()}
                  alt="Avatar"
                  style={{ width: '35px', height: '35px', borderRadius: '50%' }}
                  onError={(e) => {
                    e.target.src = Avatar; 
                  }}
                />
              ) : (
                <img src={Avatar} alt="Default Avatar" style={{ width: '35px', height: '35px' }} />
              )}
            </Button>
            <CustomizedMenus isOpen={profile} handlerClose={handleClose}>
              {checkPermission({
                name: "users",
                children: ["view_self"],
              }) && (
                <div>
                  <MenuItem
                    onClick={handleClose}
                    sx={{ gap: 1, fontSize: "18px", color: "#666" }}
                  >
                    <CgProfile size={23} />
                    Profile
                  </MenuItem>

                  <Divider sx={{ my: 0.5 }} />
                </div>
              )}
              <MenuItem
                onClick={handleClose}
                sx={{ gap: 1, fontSize: "18px", color: "#666" }}
              >
                <MdOutlineLogout size={23} />
                Logout
              </MenuItem>
            </CustomizedMenus>
          </div>
        </div>
      </div>
    </div>
  );
};

HeaderMobile.propTypes = {
  profile: propTypes.object,
  handleClick: propTypes.func.isRequired,
  handleClose: propTypes.func.isRequired,
  handleOpenMenu: propTypes.func.isRequired,
  imgProfile: propTypes.string,
  Count_inbox: propTypes.number,
  Count_notification: propTypes.number,
  handleClearCountInbox: propTypes.func,
  handleClearCountNotification: propTypes.func,
};

export default HeaderMobile;
