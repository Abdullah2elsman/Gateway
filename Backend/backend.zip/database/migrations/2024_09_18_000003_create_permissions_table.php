<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('gt_permissions', function (Blueprint $table) {
            $table->bigIncrements('id')->from(2423);
            $table->bigInteger('role_id')->unsigned();
            $table->foreign('role_id')->references('id')->on('gt_roles')->onDelete('cascade');
            $table->string('per_collection');
            $table->string('per_key');
            $table->string('per_value');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('gt_permissions');
    }
};
