<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        if (Schema::hasColumn('gt_generalmeta', 'age_group')) {
            Schema::table('gt_generalmeta', function (Blueprint $table) {
                $table->dropColumn('age_group');
            });
        }
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('gt_generalmeta', function (Blueprint $table) {
            $table->string('age_group')->nullable();
        });
    }
};
